Student name : Shaikh Tanveer Hossain
just need to give the make command to run the make file. it should ask for the number of philloshopher and cook. then you have to put the number there and hit enter. It should work.

